package thread;
/**
 * @author hunegnaw
 */
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Random;

public class CarQueue {
	Queue<Integer> queue = new ArrayDeque<Integer>();
	Random r = new Random();
	
	public CarQueue(){
		
		queue.add(r.nextInt(4));
		queue.add(r.nextInt(4));
		queue.add(r.nextInt(4));
		queue.add(r.nextInt(4));
		queue.add(r.nextInt(4));
	}
	
	public void addToQueue(){
		class myRunnable implements Runnable{
			
			@Override
			public void run() {
				
				try
				{
				while(true)
				{
					queue.add(r.nextInt(4));
					queue.add(r.nextInt(4));
					queue.add(r.nextInt(4));
					queue.add(r.nextInt(4));
					queue.add(r.nextInt(4));
					Thread.sleep(1000);
				}
				}
				catch (InterruptedException exception){
				}
				finally
				{
					
				}
			}
		}
		Runnable run = new myRunnable();
		Thread t = new Thread(run);
		t.start();
	}
	
	public int deleteQueue(){
		if(queue.isEmpty()){
			return 0;
		}
		else return queue.remove();
	}

}
